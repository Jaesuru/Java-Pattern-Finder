package util;

public class TripartiteException extends Exception{
    private String tripartiteString;
    private int occurrenceIndex;
    @Override
    public String getMessage() {
        return tripartiteString + " is a balanced tripartite string that is found at index " + occurrenceIndex + "!";
    }
    public TripartiteException(String tripartiteString, int index) {
        this.tripartiteString = tripartiteString;
        occurrenceIndex = index;
    }
}

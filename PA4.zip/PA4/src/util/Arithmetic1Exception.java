package util;

public class Arithmetic1Exception extends Exception{
    private String arithmetic1String;
    private int occurrenceIndex;
    @Override
    public String getMessage() {
        return arithmetic1String + " is an arithmetic string of order 1 that is found at index " + occurrenceIndex + "!";
    }
    public Arithmetic1Exception(String arithmetic1String, int index) {
        this.arithmetic1String = arithmetic1String;
        occurrenceIndex = index;
    }
}

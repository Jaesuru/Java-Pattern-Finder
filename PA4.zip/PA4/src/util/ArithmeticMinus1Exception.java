package util;

public class ArithmeticMinus1Exception extends Exception{
    private String arithmeticMinus1String;
    private int occurrenceIndex;
    @Override
    public String getMessage() {
        return arithmeticMinus1String + " is an arithmetic string of order -1 that is found at index " + occurrenceIndex + "!";
    }
    public ArithmeticMinus1Exception(String arithmeticMinus1String, int index) {
        this.arithmeticMinus1String = arithmeticMinus1String;
        occurrenceIndex = index;
    }
}

package main;

import util.*;

import java.util.*;

public class PatternFinder {
    private static String randomStringGenerator(int length) {// generates a string made of randomly generated lowercase
        // letters.
        Random random = new Random(System.nanoTime());
        char[] array = new char[length];
        for (int i = 0; i < length; i++)
            array[i] = (char) ('a' + random.nextInt(26));
        return new String(array);
    }

    private static void singletonMiner(String mine, int length) throws SingletonException {
        char[] mineArray = mine.toCharArray();
        for (int start = 0; start < mineArray.length - length; start++) {
            int i;
            for (i = start + 1; i < start + length; i++)
                if (mineArray[i] != mineArray[i - 1])
                    break;
            if (i == start + length)
                throw new SingletonException(mine.substring(start, start + length), start);
        }
    }

	private static void arithmeticMiner1(String mine, int length) throws Arithmetic1Exception {
        char[] mineArray = mine.toCharArray();
		for (int start = 0; start < mineArray.length - length; start++) {
			int i;
			for (i = start + 1; i < start + length; i++) {
				if (mineArray[i] - mineArray[i - 1] != 1) {
					break;
				}
			}
			if (i == start + length) {
				throw new Arithmetic1Exception(mine.substring(start, start + length), start);
			}
		}
	}

    private static void arithmeticMinerMinus1(String mine, int length) throws ArithmeticMinus1Exception {
        char[] mineArray = mine.toCharArray();
        for (int start = 0; start < mineArray.length - length; start++) {
            int i;
            for (i = start + 1; i < start + length; i++) {
                if (mineArray[i - 1] - mineArray[i] != 1) {
                    break;
                }
            }
            if (i == start + length) {
                throw new ArithmeticMinus1Exception(mine.substring(start, start + length), start);
            }
        }
    }

    private static void balancedTripartiteMiner(String mine, int length) throws TripartiteException {
        char[] mineArray = mine.toCharArray();

        for (int start = 0; start <= mineArray.length - 3 * length; start++) {
            int i;
            for (i = 0; i < length; i++) {
                if (mineArray[start + i] != mineArray[start + length + i] || mineArray[start + i] != mineArray[start + 2 * length + i]) {
                    break;
                }
            }

            if (i == length) {
                throw new TripartiteException(mine.substring(start, start + 3 * length), start);

            }
        }
    }

    private static void balancedBipartiteMiner(String mine, int length) throws BipartiteException {
        char[] mineArray = mine.toCharArray();

        for (int start = 0; start <= mineArray.length - 2 * length; start++) {
            int i;
            for (i = 0; i < length; i++) {
                if (mineArray[start + i] != mineArray[start + length + i]) {
                    break;
                }
            }

            if (i == length) {
                throw new BipartiteException(mine.substring(start, start + 2 * length), start);
            }
        }
    }

    private static void palindromeMiner(String mine, int length) throws PalindromeException {
        for (int start = 0; start <= mine.length() - length; start++) {
            String substring = mine.substring(start, start + length);

            if (isPalindrome(substring)) {
                throw new PalindromeException(substring, start);
            }
        }
    }

    public static boolean isPalindrome (String str){
        char[] arr = str.toCharArray();
        for(int left = 0, right = arr.length - 1; left < right;left++,right--)
            if(arr[left] != arr[right])
                return false;
        return true;
    }

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        //Step 1: handling input...
        System.out.println("\nEnter the length of random string (between 100 thousand to 1 billion): \n");
        int randomStringLength;

        while (true) {
            try {
                randomStringLength = keyboard.nextInt();
                if (randomStringLength < 100000 || randomStringLength > 1000000000)
                    throw new NumberFormatException();
            } catch (NumberFormatException e) {
                System.out.println("Try again!");
                keyboard.nextLine();
                continue;
            } catch(InputMismatchException e){
                System.out.println("Entered value is not an integer. Try again");
                keyboard.nextLine();
                continue;
            }
            break;
        }

        System.out.println("\nEnter the maximum length of special patterns (between 3 to 15, inclusive): \n");
        int patternMaxLength;

        while (true) {
            try {
                patternMaxLength = keyboard.nextInt();
                if (patternMaxLength < 3 || patternMaxLength > 15)
                    throw new NumberFormatException();
            } catch (NumberFormatException e) {
                System.out.println("Try again!");
                keyboard.nextInt();
                continue;
            } catch(InputMismatchException e){
            System.out.println("Entered value is not an integer. Try again");
            keyboard.nextLine();
            continue;
        }

            break;
        }

        //Step 2: generating random string...
        String randomString = randomStringGenerator(randomStringLength);
        //Step 3: finding the interesting patterns
        try {
            for (int length = patternMaxLength; length > 0; length--) {
                singletonMiner(randomString, length);
                arithmeticMiner1(randomString, length);
                arithmeticMinerMinus1(randomString, length);
                balancedTripartiteMiner(randomString, length);
                balancedBipartiteMiner(randomString, length);
                palindromeMiner(randomString, length);
            }
        } catch (Exception exp) {
            System.out.println(exp.getMessage());
        }
    }
}
